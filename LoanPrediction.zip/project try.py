import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import sklearn.linear_model
import sklearn.tree
import sklearn.ensemble
import warnings

with warnings.catch_warnings():
    warnings.simplefilter("ignore")

train = pd.read_csv('train_data.csv')
test = pd.read_csv('test_data.csv')

train['Education'].value_counts()

cols = (['ApplicantIncome','CoapplicantIncome','LoanAmount','Loan_Amount_Term'])
for c in cols:
    train.hist(column=c,bins=50)

pd.crosstab(train['Credit_History'],train['Gender'],margins=True)

train_mod = train
test_mod = test

train_mod['LoanAmount'] = train_mod['LoanAmount'].fillna(train_mod['LoanAmount'].median())
test_mod['LoanAmount'] = test_mod['LoanAmount'].fillna(test_mod['LoanAmount'].median())

train_mod['Credit_History'].fillna(1.0, inplace=True)
test_mod['Credit_History'].fillna(1.0, inplace=True)

train_mod['Gender'].fillna('male',inplace=True)
test_mod['Gender'].fillna('male',inplace=True)

number = LabelEncoder()

train_mod['Gender'] = number.fit_transform(train_mod['Gender'].astype(str))
test_mod['Gender'] = number.transform(test_mod['Gender'].astype(str))

train_mod['Education'] = number.fit_transform(train_mod['Education'].astype(str))
test_mod['Education'] = number.transform(test_mod['Education'].astype(str))

train_mod['Loan_Status'] = number.fit_transform(train_mod['Loan_Status'].astype(str))

train_mod['TotalIncome'] = train_mod['ApplicantIncome'] + train_mod['CoapplicantIncome']
test_mod['TotalIncome'] = test_mod['ApplicantIncome'] + test_mod['CoapplicantIncome']

train_mod['TotalIncome_log'] = np.log(train_mod['TotalIncome'])
test_mod['TotalIncome_log'] = np.log(test_mod['TotalIncome'])

train_mod.hist(column='TotalIncome',bins=40)
train_mod.hist(column='TotalIncome_log',bins=40)

model = sklearn.tree.DecisionTreeClassifier()

predictors = ['Credit_History','Education','Gender','TotalIncome_log','LoanAmount']

x_train = train_mod[predictors].values
y_train = train_mod['Loan_Status'].values

model.fit(x_train, y_train)

x_test = test_mod[predictors].values
predicted = model.predict(x_test)
predicted = number.inverse_transform(predicted)
test_mod['Loan_Status'] = predicted

test_mod.to_csv('LoanPrediction.csv', columns=['Loan_ID','Loan_Status'])