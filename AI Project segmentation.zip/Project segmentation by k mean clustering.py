import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Generating a synthetic dataset
data = {
    'Budget': [10000, 5000, 30000, 15000, 25000, 20000, 18000, 22000, 28000],
    'Duration': [6, 3, 12, 8, 10, 9, 7, 11, 13],
    'TeamMembers': [4, 2, 6, 4, 5, 4, 3, 5, 6],
    'Complexity': [3, 1, 5, 3, 4, 4, 2, 5, 5],
    'SuccessRate': [80, 70, 90, 85, 88, 92, 75, 87, 91]
}

# Creating a DataFrame
df = pd.DataFrame(data)

# Standardizing the data
scaler = StandardScaler()
scaled_data = scaler.fit_transform(df)

# Applying K-means clustering
kmeans = KMeans(n_clusters=4, random_state=42)
kmeans.fit(scaled_data)

# Adding cluster labels to the DataFrame
df['Cluster'] = kmeans.labels_

# Visualizing clusters
plt.scatter(df['Budget'], df['SuccessRate'], c=df['Cluster'], cmap='viridis', edgecolor='k')
plt.title('K-means Clustering of Projects')
plt.xlabel('Budget')
plt.ylabel('Success Rate')
plt.show()

# Displaying cluster centers
cluster_centers = scaler.inverse_transform(kmeans.cluster_centers_)
cluster_centers_df = pd.DataFrame(cluster_centers, columns=df.columns[:-1])
print("Cluster Centers:")
print(cluster_centers_df)
