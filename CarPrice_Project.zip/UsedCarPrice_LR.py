#IMPORTING THE MODULES
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error,r2_score,mean_absolute_error

#DATASET LOADING
df = pd.read_csv('UsedCarPrice.csv')
print(df.head())
print(df.info())
print(df.shape)

#SELECTING THE INDEPENDANT AND TARGET VARIABLES
x = df.drop(['Car_Name','Selling_Price'], axis=1 )
y = df['Selling_Price']

#ENCODING THE CATOGORICAL VALUES
x = pd.get_dummies(x, columns=['Fuel_Type','Seller_Type','Transmission'], drop_first=True)
print(x.head(1))

#SPLITTING THE DATASET
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

#LINEAR REGRESSION:
my_lr_model = LinearRegression()

#MODEL TRAINING
my_lr_model.fit(x_train, y_train)

#MAKING PREDICTIONS
y_pred = my_lr_model.predict(x_test)

#EVALUATIONS METRICES
mse = mean_squared_error(y_test, y_pred)
print('Mean Squared Error:', mse)
mae = mean_absolute_error(y_test, y_pred)
print('Mean Absolute Error:', mae)
score = r2_score(y_test, y_pred)
print('R-Squared Value is:',score)

#PREDICTION ON NEW DATA
new_data = pd.DataFrame({'Year': 2013,
                          'Present_Price':4.75,
                          'Kms_Driven':43000,
                          'Owner':0,
                          'Fuel_Type_Diesel':1,
                          'Fuel_Type_Petrol':0,
                          'Seller_Type_Individual':0,
                          'Transmission_Manual':1,
                        }, index=[0])
output = my_lr_model.predict(new_data)
print("The Predicted Car Price is:",output)

#OSB