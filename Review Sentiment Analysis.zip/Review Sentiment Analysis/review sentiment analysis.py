import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

# Download the VADER lexicon
nltk.download('vader_lexicon')
def analyze_sentiment(review):
    # Create a SentimentIntensityAnalyzer
    sid = SentimentIntensityAnalyzer()

    # Get sentiment scores
    scores = sid.polarity_scores(review)

   #   Interpret the sentiment scores
    if scores['compound'] >=0.5:
        sentiment = "Positive"
    elif scores['compound'] <=-0.05:
        sentiment = "Negative"
    else:
        sentiment = "Neutral"

    return sentiment

# Apply product reviews
reviews = [
    "This product is amazing! I love it!",
    "The quality is not as expected. I'm disappointed.",
    "It's an okay product. Nothing special.",
    "Fast shipping and great customer service. Highly recommended!",
    "gets me through a regular of use",
    "The acting was good , but the movie could not have been better"

]

# Analyze and print sentiments for each review
for idx, review in enumerate(reviews,1):
    sentiment = analyze_sentiment(review)
    print(f"Review {idx}: {review}\nSentiment: {sentiment}\n")
